Installing package: ..\space_invaders_repo\dist\space_invaders_package-0.1.tar.gz
Checking if installation was successful: pip show space_invaders_package
