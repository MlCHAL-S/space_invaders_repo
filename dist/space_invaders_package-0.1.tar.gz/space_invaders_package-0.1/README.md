This is a simple example package. You can use
[GitHub-flavored Markdown](https://github.com/MlCHAL-S/Space_invaders)
to write your content.